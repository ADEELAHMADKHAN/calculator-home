import UIKit

class ViewController: UIViewController {

    @IBOutlet var holder: UIView?
    
    var firstNumber: Double = 0
    var resultNumber: Double = 0
    var currentOperations: Operation?
    var secondNumber: Double = 0
    enum Operation
    {
        case add, subtract, multiply, divide
    }
    
    private var resultLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = .white
        label.textAlignment = .right
        label.font = UIFont(name: "Arial", size: 34)
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        setupNumberPad()
    }
        private func setupNumberPad()
    
    {
       
       
        
        let buttonSize = view.frame.size.width / 4
        let zeroButton = UIButton(frame: CGRect(x: 0, y: view.frame.height-buttonSize, width: buttonSize*2, height: buttonSize))
        zeroButton.setTitleColor(.black, for: .normal)
        zeroButton.backgroundColor = .gray
        zeroButton.setTitle("0", for: .normal)
        zeroButton.tag = 1
        holder?.addSubview(zeroButton)
        zeroButton.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
        
        
    
        let pointButton = UIButton(frame: CGRect(x:buttonSize * CGFloat(2), y: view.frame.height-buttonSize, width: buttonSize, height: buttonSize))
        pointButton.setTitleColor(.black, for: .normal)
        pointButton.backgroundColor = .gray
        pointButton.setTitle(".", for: .normal)
        pointButton.tag = 17
        holder?.addSubview(pointButton)
        pointButton.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
        
        
        
        
        let cop = ["+/-" , "%" ]
        for x in 0..<2
        {
        let cb = UIButton(frame: CGRect(x:buttonSize * CGFloat(x+1), y: view.frame.height-buttonSize*5, width: buttonSize, height: buttonSize))
        cb.setTitleColor(.black, for: .normal)
        cb.backgroundColor = .gray
        cb.setTitle(cop[x], for: .normal)
        holder?.addSubview(cb)
            
        }
        
        
        
        
        let clearButton = UIButton(frame: CGRect(x: 0, y: view.frame.height-buttonSize*5, width: buttonSize, height: buttonSize))
        clearButton.setTitleColor(.black, for: .normal)
        clearButton.backgroundColor = .gray
        clearButton.setTitle("A/C", for: .normal)
        holder?.addSubview(clearButton)
        clearButton.tag = 11
        clearButton.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
        
            
        
        
    for x in 0..<3
    {
        let buttonSize = view.frame.size.width / 4
        let button1 = UIButton(frame: CGRect(x: buttonSize * CGFloat(x), y: view.frame.height-(buttonSize * 2), width: buttonSize, height: buttonSize))
        button1.setTitleColor(.black, for: .normal)
        button1.backgroundColor = .gray
        button1.setTitle("\(x+1)", for: .normal)
        holder?.addSubview(button1)
        button1.tag = x+2
        button1.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
    }
        
        for x in 0..<3
        {
            let buttonSize = view.frame.size.width / 4
            let button2 = UIButton(frame: CGRect(x: buttonSize * CGFloat(x), y: view.frame.height-(buttonSize * 3), width: buttonSize, height: buttonSize))
            button2.setTitleColor(.black, for: .normal)
            button2.backgroundColor = .gray
            button2.setTitle("\(x+4)", for: .normal)
            holder?.addSubview(button2)
            button2.tag = x+5
            button2.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
        }
        
        for x in 0..<3
        {
            let buttonSize = view.frame.size.width / 4
            let button3 = UIButton(frame: CGRect(x: buttonSize * CGFloat(x), y: view.frame.height-(buttonSize * 4), width: buttonSize, height: buttonSize))
            button3.setTitleColor(.black, for: .normal)
            button3.backgroundColor = .gray
            button3.setTitle("\(x+7)", for: .normal)
            holder?.addSubview(button3)
            button3.tag = x+8
            button3.addTarget(self, action: #selector(numberPressed(_:)), for: .touchUpInside )
            
        }
        
        let operations = [ "=", "+" , "-" , "X" , "/" ]
        for x in 0..<5
        {
            
            let button4 = UIButton(frame: CGRect(x: buttonSize * 3, y: view.frame.height-(buttonSize * CGFloat(x+1)), width: buttonSize, height: buttonSize))
            button4.setTitleColor(.black, for: .normal)
            button4.backgroundColor = .orange
            button4.setTitle(operations[x], for: .normal)
            holder?.addSubview(button4)
            button4.tag = x+12
            button4.addTarget(self, action: #selector(operationPressed(_:)), for: .touchUpInside)
        }
    
    
        resultLabel.frame = CGRect(x: 0, y: 100, width: view.frame.size.width , height: 100)
        holder?.addSubview(resultLabel)
    
        clearButton.addTarget(self, action: #selector(clearResult), for: .touchUpInside)
        
}
    
 var val = 0
   @objc func numberPressed(_ sender: UIButton)
   {
       let tag = sender.tag - 1
       
       
       if resultLabel.text == "0"
       { resultLabel.text =  "\(tag)"}
       
       else if tag == 16
       { resultLabel.text = "\(val)" + (".")}
       
       else {resultLabel.text = "\(resultLabel.text!)\(tag)"}
       val = tag
   
   }
   
  
   
    
    @objc func operationPressed(_ sender: UIButton)
   {
       let tag = sender.tag
       if firstNumber == 0 {
           firstNumber = Double(resultLabel.text  ?? "") ?? 0
       }else {
           secondNumber = Double(resultLabel.text  ?? "") ?? 0
       }
       resultLabel.text = "0"
       
       if tag == 12
       {
           if let operation = currentOperations{
               
           switch operation {
           case .add:
               
               let result: Double = firstNumber + secondNumber
               resultLabel.text = "\(result)"
            break
           case .subtract:
               let result: Double = firstNumber - secondNumber
               resultLabel.text = "\(result)"
            break
               
           case .multiply:
               let result: Double = firstNumber * secondNumber
               resultLabel.text = "\(result)"
            break
               
           case .divide:
               let result: Double = firstNumber / secondNumber
               resultLabel.text = "\(result)"
            break
               
               
           }
        }
       }
       else if  tag==13
       {
           currentOperations = .add
       }
       else if tag == 14
       {
           currentOperations = .subtract
       }
       else if tag == 15
       {
           currentOperations = .multiply
       }
       else if  tag == 16
       {
           currentOperations = .divide
       }
       
       
       }

    
    @objc func clearResult(){
        resultLabel.text = "0"
        currentOperations = nil
        firstNumber = 0
    }
    
   

   
}
